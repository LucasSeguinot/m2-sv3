library(tools)

files = Sys.glob("results/q[12]*-*.csv")

for(i in 1:length(files)) {
	csvfile = files[i]

	print(csvfile)

	imagefile = sprintf("%s.pdf", file_path_sans_ext(csvfile))

    data <- read.csv(file=csvfile,sep=",")

	start = data[1,2]

	for(j in 1:nrow(data)) {
		if (2*data[j,2]<=start) {
		   half = j
		   break
		}
	}

	pdf(imagefile, 4, 4)

	plot(data, type="l", xlab="", ylab="")
	points(data[half,1], data[half,2])
	text(data[half,1], data[half,2], sprintf("t = %.3f", data[half,1]), pos=4)
}

files = Sys.glob("results/q4*-*.csv")

for(i in 1:length(files)) {
	csvfile = files[i]

	print(csvfile)

	imagefile = sprintf("%s.pdf", file_path_sans_ext(csvfile))

    data <- read.csv(file=csvfile,sep=",")

	pdf(imagefile, 4, 4)

	matplot(data[,1], data[, -1], type="l", lty = 1, xlab = "", ylab = "")
	legend("topright", legend = colnames(data)[-1], fill=seq_along(colnames(data)[-1]))
}

