#!/usr/bin/env python3
# -*- coding : utf-8 -*-

import numpy as np

# Duration of the simulation

reaction = "deg2"

if reaction == "deg":
    # A -> 0

    # Duration of the simulation
    tmax = 100

    # Name of each species
    names = ["A"]

    # Initial concentrations of each species
    c = np.array([100000])

    # Number of reactions
    n = 1

    # Reactants of each reaction
    r = [
        np.array([1])
    ]

    # Products of each reaction
    p = [
        np.array([0])
    ]

    # Speed of each reaction
    k = np.array([
        0.1
    ])
elif reaction == "deg2":
    # 2 * A -> 0

    # Duration of the simulation
    tmax = 0.02

    # Name of each species
    names = ["A"]

    # Initial concentrations of each species
    c = np.array([100000])

    # Number of reactions
    n = 1

    # Reactants of each reaction
    r = [
        np.array([2])
    ]

    # Products of each reaction
    p = [
        np.array([0])
    ]

    # Speed of each reaction
    k = np.array([
        0.001
    ])
elif reaction == "enz":
    # S + E -> P + E

    # Duration of the simulation
    tmax = 100

    # Name of each species
    names = ["S", "E", "P"]

    # Initial concentrations of each species
    c = np.array([100000, 0, 0])

    # Number of reactions
    n = 1

    # Reactants of each reaction
    r = [
        np.array([1, 1, 0])
    ]

    # Products of each reaction
    p = [
        np.array([0, 1, 1])
    ]

    # Speed of each reaction
    k = np.array([
        0.1
    ])
    
def choose(n, k):
    if 0 <= k <= n:
        ntok = 1
        ktok = 1
        for t in range(1, min(k, n - k) + 1):
            ntok *= n
            ktok *= t
            n -= 1
        return ntok // ktok
    else:
        return 0

assert(len(r) == n and len(p) == n and len(k) == n)

print("{},{}".format("t", ",".join(names)))
print("{},{}".format(0, ",".join([str(a) for a in c])))

t = 0
while t < tmax:
    h = np.ones(n)
    for i in range(0, n):
        for a, b in zip(r[i], c):
            h[i] *= choose(b, a)

    sumhk = sum(h*k)
    
    if sumhk == 0:
        break

    t += -np.log(np.random.random())/sumhk

    j = np.random.random() * sumhk
    for i in range(0, n+1):
        if j <= 0:
            break
        else:
            j -= h[i]*k[i]
    i = i-1

    c = c - r[i] + p[i]
    print("{},{}".format(t, ",".join([str(a) for a in c])))
