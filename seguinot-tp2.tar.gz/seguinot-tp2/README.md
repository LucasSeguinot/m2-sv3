# SV

## Dependencies

- python 3
- numpy
- optionnally matplotlib to plot the results with

## Usage

Execute `./main.py` to display the concentrations in a csv format
